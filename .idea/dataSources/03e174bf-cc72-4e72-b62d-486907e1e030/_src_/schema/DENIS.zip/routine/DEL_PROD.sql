create procedure del_prod (product_id in char, min_orders_quantity in integer) is
declare 
  var1 number := select count(*) from orderitems where prod_id = product_id;
begin
      
      if (select count(*) from orderitems where prod_id = product_id) < min_orders_quantity then
        delete from products where products.prod_id = product_id;
        delete from orders where exists (select order_num from orderitems where orderitems.prod_id = product_id);
        delete from orderitems where orderitems.prod_id = product_id;
      end if;
    
end;
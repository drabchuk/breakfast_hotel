create procedure del_not_populat_products (product_id char, min_orders_quantity in integer) as 

begin
    declare
      orders_quantity integer;
    begin
      select count(*) into orders_quantity from orderitems where prod_id = product_id;
      
      if orders_quantity < min_orders_quantity then
        delete from products where prod_id = product_id;
        delete from orders where prod_id = product_id;
        delete from orderitems where prod_id = product_id;
      end if;
      
    end;
    
end;